import type { ProfileKind } from './load'

/** Starter content for new users. Replace every line with your own details. */
export const PROFILE_TEMPLATES: Record<ProfileKind, string> = {
  resume: `# Profile
Name: Your Name
Email: you@example.com
Phone: +65 9000 0000
Location: Singapore

# Links
- GitHub: https://github.com/your-handle
- LinkedIn: https://linkedin.com/in/your-handle

# Summary
Two sentences about what you do and what you are looking for.

# Experience
## Company Name | Your Role | Jun 2024 - Present
- One achievement with a concrete result.
- Another achievement, naming the tools you used.

# Education
## University Name | BSc Your Degree | 2020 - 2023

# Skills
- Languages: TypeScript, Python
- Backend: Node.js, PostgreSQL

# Certifications
- Certification name
`,
  titles: `# Titles
- Software Engineer
- Backend Developer

# Keywords
- TypeScript
- Python

# Locations
- Singapore

# Exclude
- Senior Manager
- Intern
`,
  projects: `# Projects

## Project Name
Stack: TypeScript, PostgreSQL
Link: https://example.com
Period: 2025
One line describing what it does.
- What you built and the result.
`,
  answers: `# Answers

## Are you legally authorized to work in Singapore? | authorized to work in Singapore | work authorization
Yes

## Will you now or in the future require visa sponsorship? | visa sponsorship | sponsorship
No

## Notice period | Start date | How soon can you start?
Available to start within 2 weeks.

## Expected salary | Salary expectation
Negotiable, open to discuss based on the role.

## How did you hear about us?
Company careers page.
`,
}
