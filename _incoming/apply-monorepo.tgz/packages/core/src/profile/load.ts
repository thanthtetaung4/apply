import { contentVersion } from '../shared/hash'
import { AnswerBank } from './answer-bank'
import { IssueCollector, ProfileError } from './issues'
import { parseAnswers } from './parse-answers'
import { parseProjects } from './parse-projects'
import { parseResume } from './parse-resume'
import { parseTitles } from './parse-titles'
import { LoadedProfileSchema, type LoadedProfile } from './types'

export const PROFILE_KINDS = ['resume', 'titles', 'projects', 'answers'] as const
export type ProfileKind = (typeof PROFILE_KINDS)[number]

export const PROFILE_FILES: Record<ProfileKind, string> = {
  resume: 'resume.md',
  titles: 'titles.md',
  projects: 'projects.md',
  answers: 'answers.md',
}

export type ProfileTexts = Partial<Record<ProfileKind, string>>

export interface Profile extends LoadedProfile {
  answerBank: AnswerBank
}

export interface ParseProfileOptions {
  /** answers.md is optional by default. Set true to require it. */
  requireAnswers?: boolean
}

/** Parse the four markdown texts. Throws ProfileError listing every problem. */
export function parseProfile(texts: ProfileTexts, options: ParseProfileOptions = {}): Profile {
  const issues = new IssueCollector()
  for (const kind of PROFILE_KINDS) {
    if (!texts[kind]?.trim() && (kind !== 'answers' || options.requireAnswers)) {
      issues.add(PROFILE_FILES[kind], 'file is empty or missing')
    }
  }

  const resume = texts.resume?.trim() ? parseResume(texts.resume, issues) : null
  const titles = texts.titles?.trim() ? parseTitles(texts.titles, issues) : null
  const projects = texts.projects?.trim() ? parseProjects(texts.projects, issues) : []
  const answers = texts.answers?.trim() ? parseAnswers(texts.answers, issues) : []

  // Fail on parser problems first so users see readable messages, not schema noise.
  if (issues.hasIssues) throw new ProfileError(issues.issues)

  const candidate = {
    version: contentVersion([
      texts.resume ?? '',
      texts.titles ?? '',
      texts.projects ?? '',
      texts.answers ?? '',
    ]),
    contact: resume?.contact,
    experience: resume?.experience,
    education: resume?.education,
    skills: resume?.skills,
    certifications: resume?.certifications,
    projects,
    titles,
    answers,
  }

  // Safety net: the final shape must satisfy the schema.
  const result = LoadedProfileSchema.safeParse(candidate)
  if (!result.success) {
    throw new ProfileError(
      result.error.issues.map((i) => ({
        file: 'profile',
        message: `${i.path.join('.')}: ${i.message}`,
      })),
    )
  }
  return { ...result.data, answerBank: new AnswerBank(result.data.answers) }
}
