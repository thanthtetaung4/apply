import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import {
  PROFILE_FILES,
  PROFILE_KINDS,
  parseProfile,
  type ParseProfileOptions,
  type Profile,
  type ProfileTexts,
} from './load'
import { IssueCollector, ProfileError } from './issues'

/** Read the markdown files from a folder. Used by the demo and for importing existing files. */
export function readProfileTexts(dir: string): ProfileTexts {
  const texts: ProfileTexts = {}
  for (const kind of PROFILE_KINDS) {
    const path = join(dir, PROFILE_FILES[kind])
    if (existsSync(path)) texts[kind] = readFileSync(path, 'utf8')
  }
  return texts
}

export function loadProfileFromDir(dir: string, options?: ParseProfileOptions): Profile {
  const texts = readProfileTexts(dir)
  const missing = PROFILE_KINDS.filter((k) => k !== 'answers' && texts[k] === undefined)
  if (missing.length) {
    const issues = new IssueCollector()
    for (const k of missing)
      issues.add(PROFILE_FILES[k], `file not found at ${join(dir, PROFILE_FILES[k])}`)
    throw new ProfileError(issues.issues)
  }
  return parseProfile(texts, options)
}
