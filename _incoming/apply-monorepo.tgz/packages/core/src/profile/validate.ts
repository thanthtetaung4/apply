import { IssueCollector } from './issues'
import type { ProfileKind } from './load'
import { parseAnswers } from './parse-answers'
import { parseProjects } from './parse-projects'
import { parseResume } from './parse-resume'
import { parseTitles } from './parse-titles'
import { ContactSchema } from './types'

export interface FileValidation {
  ok: boolean
  issues: string[]
  /** Short facts about what was understood, for the editor sidebar. */
  summary: string[]
}

/**
 * Validate one markdown file on its own, so the editor can show problems while you type.
 * Cross file checks (for example titles needing at least one entry) run when the profile is loaded.
 */
export function validateProfileFile(kind: ProfileKind, text: string): FileValidation {
  const issues = new IssueCollector()
  const summary: string[] = []

  if (!text.trim()) {
    return {
      ok: kind === 'answers',
      issues: kind === 'answers' ? [] : ['The file is empty.'],
      summary,
    }
  }

  switch (kind) {
    case 'resume': {
      const r = parseResume(text, issues)
      const c = ContactSchema.safeParse({ ...r.contact, links: r.contact.links })
      if (!c.success && !issues.hasIssues) {
        for (const i of c.error.issues) issues.add('resume.md', `${i.path.join('.')}: ${i.message}`)
      }
      summary.push(
        `${r.experience.length} roles, ${r.experience.reduce((n, e) => n + e.bullets.length, 0)} bullets`,
        `${r.education.length} education entries`,
        `${r.skills.length} skill groups, ${r.skills.reduce((n, g) => n + g.skills.length, 0)} skills`,
        `${r.contact.links.length} links`,
      )
      break
    }
    case 'titles': {
      const t = parseTitles(text, issues)
      summary.push(
        `${t.titles?.length ?? 0} titles`,
        `${t.keywords?.length ?? 0} keywords`,
        `${t.locations?.length ?? 0} locations`,
        `${t.exclude?.length ?? 0} exclusions`,
      )
      break
    }
    case 'projects': {
      const p = parseProjects(text, issues)
      summary.push(`${p.length} projects`)
      break
    }
    case 'answers': {
      const a = parseAnswers(text, issues)
      summary.push(
        `${a.length} saved answers, ${a.reduce((n, e) => n + e.patterns.length, 0)} question patterns`,
      )
      break
    }
  }
  return { ok: !issues.hasIssues, issues: issues.issues.map((i) => i.message), summary }
}
