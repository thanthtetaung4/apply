import { SESSION_KEY_PATTERN, verifyApiToken } from '@apply/db'
import { z } from 'zod'
import { db, stores } from '@/lib/db'

export const dynamic = 'force-dynamic'
const MAX_BYTES = 2_000_000

const StateSchema = z.object({
  cookies: z
    .array(
      z
        .object({ name: z.string(), value: z.string(), domain: z.string().optional() })
        .passthrough(),
    )
    .max(2000),
  origins: z.array(z.object({ origin: z.string() }).passthrough()).max(200),
})

/**
 * Upload a signed-in browser session from the local sign in tool.
 * Authenticated with an API token (not cookies), so it cannot be triggered from another website.
 */
export async function PUT(req: Request, ctx: { params: Promise<{ key: string }> }) {
  const { key } = await ctx.params
  const token = /^Bearer\s+(\S+)$/.exec(req.headers.get('authorization') ?? '')?.[1]
  const who = token ? await verifyApiToken(db(), token) : null
  if (!who) return Response.json({ error: 'Invalid or missing API token.' }, { status: 401 })
  if (!SESSION_KEY_PATTERN.test(key))
    return Response.json({ error: 'Unknown site name.' }, { status: 400 })

  const text = await req.text()
  if (text.length > MAX_BYTES)
    return Response.json({ error: 'Session is too large.' }, { status: 413 })
  let json: unknown
  try {
    json = JSON.parse(text)
  } catch {
    return Response.json({ error: 'Body must be JSON.' }, { status: 400 })
  }
  const parsed = StateSchema.safeParse(json)
  if (!parsed.success)
    return Response.json(
      { error: 'Not a Playwright storage state (cookies and origins).' },
      { status: 400 },
    )
  if (parsed.data.cookies.length === 0)
    return Response.json({ error: 'The session has no cookies. Sign in first.' }, { status: 400 })

  await stores(who.userId).sessions.put(key, parsed.data as never)
  return Response.json({ ok: true, key, cookies: parsed.data.cookies.length })
}
