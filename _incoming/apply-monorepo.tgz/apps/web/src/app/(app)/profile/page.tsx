import { PROFILE_TEMPLATES } from '@apply/core/profile'
import { getProfileFiles } from '@apply/db'
import { ProfileEditor, type EditorFile } from '@/components/ProfileEditor'
import { db } from '@/lib/db'
import { profileProblem } from '@/lib/preflight'
import { requireUser } from '@/lib/session'

const META: Record<EditorFile['kind'], Pick<EditorFile, 'label' | 'file' | 'help'>> = {
  resume: {
    label: 'Resume',
    file: 'resume.md',
    help: 'Your real experience. Every tailored resume only selects and orders what is written here. Nothing is invented.',
  },
  titles: {
    label: 'Titles',
    file: 'titles.md',
    help: 'The job titles to search for, and words that rule a job out.',
  },
  projects: {
    label: 'Projects',
    file: 'projects.md',
    help: 'Projects to pick from. Each needs a Stack line.',
  },
  answers: {
    label: 'Answers',
    file: 'answers.md',
    help: 'Answers to questions forms ask. A ## heading is the question (use | for alternative wordings), the text below is the answer.',
  },
}

export default async function ProfilePage({
  searchParams,
}: {
  searchParams: Promise<{ welcome?: string }>
}) {
  const user = await requireUser()
  const sp = await searchParams
  const files = await getProfileFiles(db(), user.id)
  const problem = await profileProblem(user.id)
  const list: EditorFile[] = (['resume', 'titles', 'projects', 'answers'] as const).map((kind) => ({
    kind,
    ...META[kind],
    content: files[kind].content,
    revision: files[kind].revision,
    template: PROFILE_TEMPLATES[kind],
  }))
  return (
    <>
      <div className="head">
        <div>
          <h1>Profile</h1>
          <p className="muted">
            These four files are everything the app knows about you. They are saved to your account.
          </p>
        </div>
      </div>
      {sp.welcome && (
        <div className="banner ok">
          <strong>Welcome.</strong> The files below are a starter template. Replace the details in
          resume.md first.
        </div>
      )}
      {problem && !sp.welcome && (
        <div className="banner warn" style={{ whiteSpace: 'pre-wrap' }}>
          {problem}
        </div>
      )}
      <ProfileEditor files={list} />
    </>
  )
}
