import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { contentVersion } from '../shared/hash'
import { AnswerBank } from './answer-bank'
import { IssueCollector, ProfileError } from './issues'
import { parseAnswers } from './parse-answers'
import { parseProjects } from './parse-projects'
import { parseResume } from './parse-resume'
import { parseTitles } from './parse-titles'
import { LoadedProfileSchema, type LoadedProfile } from './types'

export const PROFILE_FILES = {
  resume: 'resume.md',
  titles: 'titles.md',
  projects: 'projects.md',
  answers: 'answers.md',
} as const

export interface Profile extends LoadedProfile {
  answerBank: AnswerBank
}

export interface LoadProfileOptions {
  /** answers.md is optional by default. Set true to require it. */
  requireAnswers?: boolean
}

/** Parse the four markdown files from a directory. Throws ProfileError listing every problem. */
export function loadProfile(dir: string, options: LoadProfileOptions = {}): Profile {
  const issues = new IssueCollector()
  const texts: Record<keyof typeof PROFILE_FILES, string> = {
    resume: '',
    titles: '',
    projects: '',
    answers: '',
  }

  for (const key of Object.keys(PROFILE_FILES) as (keyof typeof PROFILE_FILES)[]) {
    const name = PROFILE_FILES[key]
    const path = join(dir, name)
    if (existsSync(path)) {
      texts[key] = readFileSync(path, 'utf8')
    } else if (key !== 'answers' || options.requireAnswers) {
      issues.add(name, `file not found at ${path}`)
    }
  }

  const resume = texts.resume ? parseResume(texts.resume, issues) : null
  const titles = texts.titles ? parseTitles(texts.titles, issues) : null
  const projects = texts.projects ? parseProjects(texts.projects, issues) : []
  const answers = texts.answers ? parseAnswers(texts.answers, issues) : []

  // Fail on parser problems first so users see readable messages, not schema noise.
  if (issues.hasIssues) throw new ProfileError(issues.issues)

  const candidate = {
    version: contentVersion([texts.resume, texts.titles, texts.projects, texts.answers]),
    contact: resume?.contact,
    experience: resume?.experience,
    education: resume?.education,
    skills: resume?.skills,
    certifications: resume?.certifications,
    projects,
    titles,
    answers,
  }

  // Safety net: the final shape must satisfy the schema.
  const result = LoadedProfileSchema.safeParse(candidate)
  if (!result.success) {
    throw new ProfileError(
      result.error.issues.map((i) => ({ file: 'profile', message: `${i.path.join('.')}: ${i.message}` })),
    )
  }
  return { ...result.data, answerBank: new AnswerBank(result.data.answers) }
}
